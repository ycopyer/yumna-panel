-- YumnaPanel SQL Dump
-- Database: wp_4d5f2f
-- Generated: 2026-01-09T01:35:27.384Z

USE `wp_4d5f2f`;

