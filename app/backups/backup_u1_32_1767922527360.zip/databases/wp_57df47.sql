-- YumnaPanel SQL Dump
-- Database: wp_57df47
-- Generated: 2026-01-09T01:35:27.391Z

USE `wp_57df47`;

