-- YumnaPanel SQL Dump
-- Database: wp_0c08ce
-- Generated: 2026-01-09T01:35:27.371Z

USE `wp_0c08ce`;

