-- YumnaPanel SQL Dump
-- Database: wp_52cf41
-- Generated: 2026-01-09T01:35:27.389Z

USE `wp_52cf41`;

