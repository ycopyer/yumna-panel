-- YumnaPanel SQL Dump
-- Database: wp_ced4c0
-- Generated: 2026-01-09T01:35:27.397Z

USE `wp_ced4c0`;

