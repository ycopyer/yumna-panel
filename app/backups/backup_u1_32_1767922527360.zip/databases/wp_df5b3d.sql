-- YumnaPanel SQL Dump
-- Database: wp_df5b3d
-- Generated: 2026-01-09T01:35:27.398Z

USE `wp_df5b3d`;

