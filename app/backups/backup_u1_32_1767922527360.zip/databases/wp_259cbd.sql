-- YumnaPanel SQL Dump
-- Database: wp_259cbd
-- Generated: 2026-01-09T01:35:27.379Z

USE `wp_259cbd`;

