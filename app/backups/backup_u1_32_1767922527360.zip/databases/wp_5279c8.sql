-- YumnaPanel SQL Dump
-- Database: wp_5279c8
-- Generated: 2026-01-09T01:35:27.388Z

USE `wp_5279c8`;

