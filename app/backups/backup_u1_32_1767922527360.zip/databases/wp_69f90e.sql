-- YumnaPanel SQL Dump
-- Database: wp_69f90e
-- Generated: 2026-01-09T01:35:27.394Z

USE `wp_69f90e`;

