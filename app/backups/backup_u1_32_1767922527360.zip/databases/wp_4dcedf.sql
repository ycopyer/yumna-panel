-- YumnaPanel SQL Dump
-- Database: wp_4dcedf
-- Generated: 2026-01-09T01:35:27.387Z

USE `wp_4dcedf`;

