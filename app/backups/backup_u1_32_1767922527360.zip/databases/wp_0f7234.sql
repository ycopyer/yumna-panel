-- YumnaPanel SQL Dump
-- Database: wp_0f7234
-- Generated: 2026-01-09T01:35:27.376Z

USE `wp_0f7234`;

