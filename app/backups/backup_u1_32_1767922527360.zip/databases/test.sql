-- YumnaPanel SQL Dump
-- Database: test
-- Generated: 2026-01-09T01:35:27.369Z

USE `test`;

