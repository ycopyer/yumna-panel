-- YumnaPanel SQL Dump
-- Database: wp_797489
-- Generated: 2026-01-09T01:35:27.395Z

USE `wp_797489`;

