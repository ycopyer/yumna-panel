-- YumnaPanel SQL Dump
-- Database: wp_4a7240
-- Generated: 2026-01-09T01:35:27.382Z

USE `wp_4a7240`;

