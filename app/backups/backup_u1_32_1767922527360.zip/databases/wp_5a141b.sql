-- YumnaPanel SQL Dump
-- Database: wp_5a141b
-- Generated: 2026-01-09T01:35:27.392Z

USE `wp_5a141b`;

